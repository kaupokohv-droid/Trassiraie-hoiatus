plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "ee.rmk.trassihoiatus"; compileSdk = 35
 defaultConfig { applicationId = "ee.rmk.trassihoiatus"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" } }
